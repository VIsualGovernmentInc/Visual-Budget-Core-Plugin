<?php

/**
 * Fired during plugin deactivation
 */

class VisualBudget_Deactivator {

	/**
	 * Deactivator hook.
     */
	public static function deactivate() {

	}

}
